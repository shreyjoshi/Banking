package beans;

public class Customer {
	String cname,cadd,cmob,cemail,accno,accpass;
	Double balance;
	public Customer()
	{
		
	}
		public Customer(String cname,String cadd,String cmob,String cemail,String accno,String accpass,Double balance)
		{
			this.cname=cname;
			this.cadd=cadd;
			this.cmob=cmob;
			this.cemail=cemail;
			this.accno=accno;
			this.accpass=accpass;
			this.balance=balance;
		}
		public String getCname() {
			return cname;
		}
		public void setCname(String cname) {
			this.cname = cname;
		}
		public String getCadd() {
			return cadd;
		}
		public void setCadd(String cadd) {
			this.cadd = cadd;
		}
		public String getCmob() {
			return cmob;
		}
		public void setCmob(String cmob) {
			this.cmob = cmob;
		}
		public String getCemail() {
			return cemail;
		}
		public void setCemail(String cemail) {
			this.cemail = cemail;
		}
		public String getAccno() {
			return accno;
		}
		public void setAccno(String accno) {
			this.accno = accno;
		}
		public String getAccpass() {
			return accpass;
		}
		public void setAccpass(String accpass) {
			this.accpass = accpass;
		}
		public Double getBalance() {
			return balance;
		}
		public void setBalance(Double balance) {
			this.balance = balance;
		}
		
}
